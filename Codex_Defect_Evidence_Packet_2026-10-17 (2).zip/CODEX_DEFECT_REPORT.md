# [Windows][Codex] 266 CLOSE_WAIT sockets retained in one signed codex.exe process; Windows RADAR_PRE_LEAK_64 event

**Case reference:** CDX-WIN-20261017-01  
**Status:** Evidence-backed defect candidate; engineering investigation requested. Not submitted.  
**Severity:** Undetermined. Possible resource-retention/reconnect issue, not a verified security vulnerability.  
**Captured:** 2026-10-17 12:43:56 EDT (UTC-04:00)

## Summary
A local Windows network snapshot captured **266 TCP sockets in CLOSE_WAIT** attributed to a single `codex.exe` process (PID **29300**). Every socket had a distinct local port. The same 266 sockets were independently observed as `CLOSE_WAIT` during a separate **~56-minute** read-only TRACE DECK session. Windows Error Reporting separately flagged `codex.exe` with **Event ID 1001, RADAR_PRE_LEAK_64**, at **2026-10-16 21:02:25 EDT**.

This is sufficient to request investigation of socket lifecycle/connection cleanup and related resource usage. It does **not** prove the WER warning and sockets share a root cause.

## Environment and provenance
- Windows 11 Home 64-bit, build **26300**.
- Desktop Codex Windows package path includes `OpenAI.Codex_26.1013.3656.0` (package path observed; runtime `codex.exe --version` not collected).
- Signed binary: `%LOCALAPPDATA%\OpenAI\Codex\bin\e78bad9887fa50cf\codex.exe`.
- Signature status **Valid**, signer **OpenAI OpCo, LLC**.
- Binary SHA256: `9ECB9DF2ECAFCC00542EF0966C6F1737A81397DC9531B0A4B178238E2BF4A46D`.
- Main process **PID 29300**, started **2026-10-16 10:18:32 EDT**.

## Confirmed observations
1. **Snapshot at 12:43:56 EDT on Oct 17:** 266 `CLOSE_WAIT` connections under PID 29300: **168** to `172.64.155.209:443`, **98** to `104.18.32.47:443`. Destinations are TCP 443; their role has not been authenticated by this evidence.
2. **266 distinct local ports.** There are **272 `Bound` entries** for the same PID, and **all 266 `CLOSE_WAIT` local ports also appear as `Bound`**. `Bound` and `CLOSE_WAIT` should not be summed as separate connections.
3. **Oldest socket creation timestamp:** **2026-10-16 10:18:33 EDT**, approximately **26 h 25 min** before collection. Creation time is **not** evidence that it had remained in `CLOSE_WAIT` for that entire period.
4. **Independent monitoring:** TRACE DECK observed 266 `CLOSE_WAIT` sockets at start (**Oct 17 2026 11:05:53 AM EDT**) and no `no_longer_observed` event for those sockets through its last sample (**Oct 17 2026 12:01:30 PM EDT**). It measures a 56-minute observation window, not lifetime `CLOSE_WAIT` duration.
5. **Windows WER:** Oct 16, **21:02:25 EDT**, Application Event 1001 / Record ID 50598, `RADAR_PRE_LEAK_64`, P1=`codex.exe`. The WER entry does not contain a confirmed causal link to these sockets or their PID.
6. **TRACE DECK chain:** all **5,968** JSONL records passed sequence, SHA-256, and previous-hash consistency checks. This establishes internal file consistency only, not external chain of custody.

## Expected versus observed
**Expected:** Network connections that have received peer FIN should be fully closed promptly when no longer needed, absent a documented deliberate retention policy.  
**Observed:** A single Codex process retained a large `CLOSE_WAIT` population during at least 56 minutes of independent observation, with many sockets created the previous day. A Windows leak-precursor report for Codex was recorded during that operating period.

## Reproduction status
**Not yet reproduced from a clean restart.** A follow-up capture should: (a) save work, (b) restart Codex, (c) record the baseline TCP states, (d) repeat the normal workload, (e) collect at regular intervals, and (f) compare process memory and handle counts alongside socket states. `OPTIONAL_RETEST_READ_ONLY.ps1` provides a point-in-time socket export.

## Requested engineering investigation
- Examine Codex's handling of peer-closed TCP sessions and possible missed socket shutdown/cleanup.
- Correlate connection churn/reconnection or streaming RPC behavior with retained `CLOSE_WAIT` handles.
- Correlate WER `RADAR_PRE_LEAK_64` with memory, handle and socket metrics, without assuming causation.
- Determine whether cleanup is expected on idle and whether socket count grows with normal use.

## Evidence exhibits
- `EXHIBIT_A_266_CLOSE_WAIT.csv`: all 266 affected TCP connections, ports and creation timestamps.
- `EXHIBIT_B_WINDOWS_WER_1001.txt`: minimal Windows error event extract.
- `EXHIBIT_C_TRACE_SUMMARY.json`: 56-minute independent-monitor summary and integrity result.
- `EXHIBIT_D_PROVENANCE.txt`: signed binary, OS and original evidence file hashes.
- `EXHIBIT_E_FIREWALL_CONTEXT.txt`: separate October 15 network profile/reconnection explanation.
- `OPTIONAL_RETEST_READ_ONLY.ps1`: repeatable socket snapshot, without modifying settings.

## Boundaries and privacy
This packet omits the workstation name, username, Wi-Fi SSID, process command lines, chat/task content, and full antivirus logs. It is a **technical defect candidate**, **not** a finding of exploitation, malicious access, data theft, or a proven memory leak. Full source files are retained separately and should be shared privately only after reviewing sensitive contents.
