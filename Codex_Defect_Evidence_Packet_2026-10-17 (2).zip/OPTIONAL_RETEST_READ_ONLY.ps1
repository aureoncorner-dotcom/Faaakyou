# Read-only, run in PowerShell. Does not stop processes or alter networking.
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$out = Join-Path ([Environment]::GetFolderPath('Desktop')) "CODEX_SOCKET_RETEST_$stamp.csv"
$pids = @(Get-CimInstance Win32_Process -Filter "Name='codex.exe'" |
    Select-Object -ExpandProperty ProcessId)
if (-not $pids.Count) { Write-Host 'No running codex.exe processes detected.'; return }
Get-NetTCPConnection -ErrorAction SilentlyContinue |
    Where-Object { $pids -contains $_.OwningProcess } |
    Select-Object OwningProcess,State,LocalAddress,LocalPort,RemoteAddress,RemotePort,CreationTime |
    Export-Csv -NoTypeInformation -Encoding UTF8 -Path $out
Import-Csv $out | Group-Object OwningProcess,State | Sort-Object Count -Descending |
    Format-Table Count,Name -AutoSize
Write-Host "Saved: $out"
